import { Component, OnInit } from '@angular/core';
import { QuizService } from '../shared/quiz.service';
import { Router } from '@angular/router';
import {Student_Details} from '../Models/Student_Details';
import { MustMatch } from './confirm-password.validator';
import { NgForm, FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: Student_Details;


  constructor(private quizService: QuizService,private route : Router,private fb: FormBuilder) {}
  
   RegForm :FormGroup;
  // ngOnInit() {
  //   this.RegForm = new FormGroup({
  //     S_Name: new FormControl(),
  //     S_Email: new FormControl("",Validators.email),
  //     S_password: new FormControl(),
  //     S_Mobile: new FormControl(),
  //     S_DOB:new FormControl(),
  //     S_state:new FormControl(),
  //     S_city:new FormControl(),
  //     S_YOC:new FormControl(),
  //     S_Qualification:new FormControl(),
  //     ConfirmPassword: new FormControl()
  //   },

  //   { validator:  MustMatch('S_password', 'ConfirmPassword')}
    
    
  //   );
  // }


  ngOnInit() {
  


    this.RegForm = this.fb.group({
      S_Name: new FormControl(),
      S_Email: new FormControl("", Validators.email),
      S_password: new FormControl(),
      ConfirmPassword: new FormControl(),
      S_state:new FormControl(),
      S_city:new FormControl(),
      S_DOB:new FormControl(),
      S_Qualification: new FormControl(),
      S_Mobile:new FormControl(),
      S_YOC:new FormControl()
      },
        { validator:  MustMatch('S_password', 'ConfirmPassword')}
      
      
      );
    }

  city:string[]
  selectedState: string = '';

changecity(event: any) {
  

  this.selectedState = event.target.value;
  if(this.selectedState=="Karnataka")
{
  this.city=  ["select",            "Bagalkot","Ballari (Bellary)","Belagavi (Belgaum)",  "Bengaluru (Bangalore) Rural",  "Bengaluru (Bangalore) Urban","Bidar",
  "Chamarajanagar","Chikballapur","Chikkamagaluru (Chikmagalur)","Chitradurga","Dakshina Kannada","Davangere","Dharwad","Gadag","Hassan",
  "Haveri","Kalaburagi (Gulbarga)","Kodagu","Kolar","Koppal","Mandya","Mysuru (Mysore)","Raichur","Ramanagara","Shivamogga (Shimoga)","Tumakuru (Tumkur)","Udupi",
  "Uttara Kannada (Karwar)","Vijayapura (Bijapur)","Yadgir"
]
}
else if(this.selectedState=="Maharashtra")
{
this.city=  ["select",     "Ahmednagar","Akola","Amravati","Aurangabad","Beed","Bhandara","Buldhana","Chandrapur","Dhule",
"Gadchiroli","Gondia","Hingoli","Jalgaon","Jalna","Kolhapur","Latur","Mumbai City","Mumbai Suburban","Nagpur","Nanded",
"Nandurbar","Nashik","Osmanabad","Palghar","Parbhani","Pune","Raigad","Ratnagiri","Sangli","Satara","Sindhudurg","Solapur",
"Thane","Wardha","Washim","Yavatmal"]
 
}
else if(this.selectedState=="Andhra Pradesh")
{
this.city=  ["select",   "Anantapur",
"Chittoor","East Godavari","Guntur","Krishna","Kurnool","Nellore","Prakasam","Srikakulam","Visakhapatnam","Vizianagaram","West Godavari",
"YSR Kadapa"]
 
}
else if(this.selectedState=="Arunachal Pradesh")
{
this.city=  ["select",  "Tawang","West Kameng","East Kameng","Papum Pare","Kurung Kumey","Kra Daadi",
"Lower Subansiri","Upper Subansiri","West Siang","East Siang","Siang","Upper Siang","Lower Siang","Lower Dibang Valley","Dibang Valley",
"Anjaw","Lohit","Namsai","Changlang","Tirap","Longding"]
 
}
else if(this.selectedState=="Assam")
{
this.city=  ["select","Baksa","Barpeta","Biswanath","Bongaigaon","Cachar","Charaideo","Chirang","Darrang","Dhemaji",
"Dhubri","Dibrugarh","Goalpara","Golaghat","Hailakandi","Hojai","Jorhat","Kamrup Metropolitan","Kamrup","Karbi Anglong","Karimganj",
"Kokrajhar","Lakhimpur","Majuli","Morigaon","Nagaon","Nalbari","Dima Hasao","Sivasagar","Sonitpur","South Salmara-Mankachar",
"Tinsukia","Udalguri","West Karbi Anglong"]
 
}
else if(this.selectedState=="Bihar")
{
this.city=  ["select","Araria","Arwal","Aurangabad","Banka","Begusarai","Bhagalpur","Bhojpur","Buxar","Darbhanga","East Champaran (Motihari)",
"Gaya","Gopalganj","Jamui","Jehanabad","Kaimur (Bhabua)","Katihar","Khagaria","Kishanganj","Lakhisarai","Madhepura",
"Madhubani","Munger (Monghyr)","Muzaffarpur","Nalanda","Nawada","Patna","Purnia (Purnea)","Rohtas","Saharsa","Samastipur",
"Saran","Sheikhpura","Sheohar","Sitamarhi","Siwan","Supaul","Vaishali","West Champaran"]
 
}
else if(this.selectedState=="Chhattisgarh")
{
this.city=  ["select",  "Balod","Baloda Bazar","Balrampur","Bastar","Bemetara","Bijapur","Bilaspur","Dantewada (South Bastar)",
"Dhamtari","Durg","Gariyaband","Janjgir-Champa","Jashpur","Kabirdham (Kawardha)","Kanker (North Bastar)","Kondagaon","Korba","Korea (Koriya)",
"Mahasamund","Mungeli","Narayanpur","Raigarh","Raipur","Rajnandgaon","Sukma","Surajpur  ","Surguja"]
 
}
else if(this.selectedState=="Goa")
{
this.city=  ["select",  "North Goa","South Goa"]
 
}
else if(this.selectedState=="Gujarat")
{
this.city=  ["select",    "Ahmedabad","Amreli","Anand","Aravalli","Banaskantha (Palanpur)","Bharuch","Bhavnagar",
"Botad","Chhota Udepur","Dahod","Dangs (Ahwa)","Devbhoomi Dwarka","Gandhinagar","Gir Somnath","Jamnagar",
"Junagadh","Kachchh","Kheda (Nadiad)","Mahisagar","Mehsana","Morbi","Narmada (Rajpipla)","Navsari","Panchmahal (Godhra)","Patan",
"Porbandar","Rajkot","Sabarkantha (Himmatnagar)","Surat","Surendranagar","Tapi (Vyara)","Vadodara","Valsad"]
 
}
else if(this.selectedState=="Haryana")
{
this.city=  ["select",  "Ambala","Bhiwani","Charkhi Dadri","Faridabad","Fatehabad","Gurgaon","Hisar","Jhajjar",
"Jind","Kaithal","Karnal","Kurukshetra","Mahendragarh","Mewat","Palwal","Panchkula","Panipat","Rewari","Rohtak","Sirsa",
"Sonipat","Yamunanagar"]
 
}
else if(this.selectedState=="Himachal Pradesh")
{
this.city=  ["select", "Bilaspur","Chamba","Hamirpur","Kangra","Kinnaur","Kullu","Lahaul &amp; Spiti","Mandi","Shimla",
"Sirmaur (Sirmour)","Solan","Una"]
 
}
else if(this.selectedState=="Jharkhand")
{
this.city=  ["select",   "Bokaro","Chatra","Deoghar","Dhanbad","Dumka","East Singhbhum","Garhwa","Giridih","Godda","Gumla","Hazaribag",
"Jamtara","Khunti","Koderma","Latehar","Lohardaga","Pakur","Palamu","Ramgarh","Ranchi","Sahibganj","Seraikela-Kharsawan","Simdega",
"West Singhbhum"]
 
}
else if(this.selectedState=="Kerala")
{
this.city=  ["select",   "Alappuzha",
"Ernakulam","Idukki","Kannur","Kasaragod","Kollam","Kottayam","Kozhikode","Malappuram","Palakkad","Pathanamthitta","Thiruvananthapuram","Thrissur","Wayanad"]
 
}
else if(this.selectedState=="Madhya Pradesh")
{
this.city=  ["select",      "Agar Malwa","Alirajpur","Anuppur","Ashoknagar","Balaghat","Barwani","Betul","Bhind","Bhopal",
"Burhanpur","Chhatarpur","Chhindwara","Damoh","Datia","Dewas","Dhar","Dindori","Guna","Gwalior","Harda",
"Hoshangabad","Indore","Jabalpur","Jhabua","Katni","Khandwa","Khargone","Mandla","Mandsaur","Morena","Narsinghpur",
"Neemuch","Panna","Raisen","Rajgarh","Ratlam","Rewa","Sagar","Satna","Sehore",
"Seoni","Shahdol","Shajapur","Sheopur","Shivpuri","Sidhi","Singrauli","Tikamgarh","Ujjain","Umaria","Vidisha"]
 
}
else if(this.selectedState=="Manipur")
{
this.city=  ["select",         "Bishnupur","Chandel","Churachandpur","Imphal East","Imphal West","Jiribam","Kakching","Kamjong",
"Kangpokpi","Noney","Pherzawl","Senapati","Tamenglong","Tengnoupal","Thoubal","Ukhrul"]
 
}
else if(this.selectedState=="Meghalaya")
{
this.city=  ["select",   "East Garo Hills","East Jaintia Hills","East Khasi Hills","North Garo Hills","Ri Bhoi","South Garo Hills","South West Garo Hills ",
"South West Khasi Hills","West Garo Hills","West Jaintia Hills","West Khasi Hills"]
 
}
else if(this.selectedState=="Mizoram")
{
this.city=  ["select", "Aizawl","Champhai","Kolasib","Lawngtlai","Lunglei","Mamit","Saiha","Serchhip"]
 
}
else if(this.selectedState=="Nagaland")
{
this.city=  ["select","Dimapur","Kiphire","Kohima","Longleng","Mokokchung","Mon","Peren","Phek","Tuensang","Wokha","Zunheboto"]
 
}
else if(this.selectedState=="Odisha")
{
this.city=  ["select",   "Angul","Balangir","Balasore","Bargarh","Bhadrak","Boudh","Cuttack","Deogarh",
"Dhenkanal","Gajapati","Ganjam","Jagatsinghapur","Jajpur","Jharsuguda","Kalahandi","Kandhamal","Kendrapara",
"Kendujhar (Keonjhar)","Khordha","Koraput","Malkangiri","Mayurbhanj","Nabarangpur","Nayagarh","Nuapada","Puri","Rayagada",
"Sambalpur","Sonepur","Sundargarh"]
 
}
else if(this.selectedState=="Punjab")
{
this.city=  ["select", "Amritsar","Barnala","Bathinda","Faridkot","Fatehgarh Sahib","Fazilka","Ferozepur","Gurdaspur","Hoshiarpur","Jalandhar","Kapurthala","Ludhiana",
"Mansa","Moga","Muktsar","Nawanshahr (Shahid Bhagat Singh Nagar)","Pathankot","Patiala","Rupnagar","Sahibzada Ajit Singh Nagar (Mohali)","Sangrur",
"Tarn Taran"]
 
}
else if(this.selectedState=="Rajasthan")
{
this.city=  ["select",  "Ajmer","Alwar","Banswara","Baran","Barmer","Bharatpur","Bhilwara","Bikaner","Bundi","Chittorgarh",
"Dausa","Dholpur","Dungarpur","Hanumangarh","Jaipur","Jaisalmer","Jalore","Jhalawar","Jhunjhunu","Jodhpur","Karauli","Kota",
"Nagaur","Pali","Pratapgarh","Rajsamand","Sawai Madhopur","Sikar","Sirohi","Sri Ganganagar","Tonk",
"Udaipur"]
 
}
else if(this.selectedState=="Sikkim")
{
this.city=  ["select",   "East Sikkim",
"North Sikkim",
"South Sikkim",
"West Sikkim"]
 
}
else if(this.selectedState=="Tamil Nadu")
{
this.city=  ["select", "Ariyalur","Chennai","Coimbatore","Cuddalore","Dharmapuri","Dindigul","Erode","Kanchipuram","Kanyakumari",
"Karur","Krishnagiri","Madurai","Nagapattinam","Namakkal","Nilgiris","Perambalur","Pudukkottai","Ramanathapuram","Salem",
"Sivaganga","Thanjavur","Theni","Thoothukudi (Tuticorin)","Tiruchirappalli","Tirunelveli","Tiruppur","Tiruvallur","Tiruvannamalai",
"Tiruvarur","Vellore","Viluppuram","Virudhunagar"]
 
}
else if(this.selectedState=="Telangana")
{
this.city=  ["select", "Adilabad","Bhadradri Kothagudem","Hyderabad","Jagtial","Jangaon","Jayashankar Bhoopalpally","Jogulamba Gadwal",
"Kamareddy","Karimnagar","Khammam","Komaram Bheem Asifabad","Mahabubabad","Mahabubnagar","Mancherial","Medak","Medchal","Nagarkurnool",
"Nalgonda","Nirmal","Nizamabad","Peddapalli","Rajanna Sircilla","Rangareddy","Sangareddy","Siddipet","Suryapet",
"Vikarabad","Wanaparthy","Warangal (Rural)","Warangal (Urban)","Yadadri Bhuvanagiri"]
 
}


else if(this.selectedState=="Tripura")
{
this.city=  ["select",   "Dhalai","Gomati","Khowai","North Tripura","Sepahijala","South Tripura","Unakoti","West Tripura"]
 
}
else if(this.selectedState=="Uttar Pradesh")
{
this.city=  ["select","Agra","Aligarh","Allahabad","Ambedkar Nagar","Amethi (Chatrapati Sahuji Mahraj Nagar)","Amroha (J.P. Nagar)","Auraiya",
"Azamgarh","Baghpat","Bahraich","Ballia","Balrampur","Banda","Barabanki","Bareilly","Basti","Bhadohi","Bijnor","Budaun",
"Bulandshahr","Chandauli","Chitrakoot","Deoria","Etah","Etawah","Faizabad","Farrukhabad","Fatehpur","Firozabad","Gautam Buddha Nagar","Ghaziabad",
"Ghazipur","Gonda","Gorakhpur","Hamirpur","Hapur (Panchsheel Nagar)","Hardoi","Hathras","Jalaun","Jaunpur",
"Jhansi","Kannauj","Kanpur Dehat","Kanpur Nagar","Kanshiram Nagar (Kasganj)","Kaushambi","Kushinagar (Padrauna)","Lakhimpur - Kheri",
"Lalitpur","Lucknow","Maharajganj","Mahoba","Mainpuri","Mathura","Mau","Meerut","Mirzapur","Moradabad","Muzaffarnagar","Pilibhit",
"Pratapgarh","RaeBareli","Rampur","Saharanpur","Sambhal (Bhim Nagar)","Sant Kabir Nagar","Shahjahanpur","Shamali (Prabuddh Nagar)",
"Shravasti","Siddharth Nagar","Sitapur","Sonbhadra","Sultanpur","Unnao","Varanasi"]
 
}
else if(this.selectedState=="Uttarakhand")
{
this.city=  ["select", "Almora",
"Bageshwar","Chamoli","Champawat","Dehradun","Haridwar","Nainital","Pauri Garhwal","Pithoragarh","Rudraprayag","Tehri Garhwal","Udham Singh Nagar","Uttarkashi"]
 
}
else if(this.selectedState=="West Bengal")
{
this.city=  ["select",   "Alipurduar",
"Bankura","Birbhum","Burdwan (Bardhaman)","Cooch Behar","Dakshin Dinajpur (South Dinajpur)","Darjeeling","Hooghly","Howrah",
"Jalpaiguri","Kalimpong","Kolkata","Malda","Murshidabad","Nadia","North 24 Parganas","Paschim Medinipur (West Medinipur)","Purba Medinipur (East Medinipur)",
"Purulia","South 24 Parganas","Uttar Dinajpur (North Dinajpur)"]
 
}


}




onSubmit(obj:Student_Details)
  {
    
//alert(obj.S_Name);
    this.quizService.insertParticipant(obj).subscribe(
    (data:any) =>{


      
      localStorage.clear();
      localStorage.setItem('user',JSON.stringify(data));
      alert(this.user.S_Name);
      alert("Registration sucessfull");
      
    }
    );
    this.route.navigate(['/login']);
  }

  // success(){
  //   alert("registerd successfully")
  // }

}



