import { Injectable } from '@angular/core';
import{ HttpClient } from '@angular/common/http';
import {Student_Details} from '../Models/Student_Details'
import {  Results } from '../Models/Results';
import { Admin_Details } from '../Models/Admin_Details';

//import { questionTEST } from '../Models/questionTEST';

@Injectable({
  providedIn: 'root'
})
export class QuizService {
//============Properties=======
readonly rootUrl ="http://localhost:60975";
qns:any[];
seconds: number;
timer;
qnProgress: number;
correctAnswerCount: number = 0;

  constructor(private http : HttpClient) { }

  
  //=======Helper Methods=======
insertParticipant(obj:Student_Details){
  //alert(name)
  //alert(email)
  
  // alert(obj.S_Name)
  
  return this.http.post(this.rootUrl + '/api/InsertStudent',obj);
}

getQuestion(sD:string){
  return this.http.get(this.rootUrl + '/api/Questions?ss='+sD);
}

getAnswers() {
  var body = this.qns.map(x => x.QnID);
  return this.http.post(this.rootUrl + '/api/Answers',body);
}

getParticipantName() {
  var participant = JSON.parse(localStorage.getItem('user'));
  return participant.S_Name;
}




UpdateResult(obj2:Results) {
  

  return this.http.post(this.rootUrl + "/api/UpdateOutput", obj2);
}



getLogdetails(obj2:Student_Details){
 
  return this.http.post(this.rootUrl+"/api/login",obj2);
}


getadminLogdetails(obj4:Admin_Details){


  return this.http.post(this.rootUrl+"/api/Admin",obj4);
}

getID(email:string)
{

  return this.http.get(this.rootUrl+"/api/getID?email="+email)

}




}


