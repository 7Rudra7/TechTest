import {Routes} from '@angular/router'
import { RegisterComponent } from './register/register.component';
import { QuizComponent } from './quiz/quiz.component';
import { ResultComponent } from './result/result.component';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './login/login.component';
import { ExamCIComponent } from './exam-ci/exam-ci.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ADDQuesComponent } from './addques/addques.component';
import { AdminOptionComponent } from './admin-option/admin-option.component';

export const appRoutes : Routes=[
    {path:'register',component:RegisterComponent},
    {path:'exam-ci',component:ExamCIComponent},
    {path:'login',component:LoginComponent},
    {path:'quiz',component:QuizComponent,canActivate:[AuthGuard]},
    {path:'result',component:ResultComponent,canActivate:[AuthGuard]},
    {path:'',redirectTo:'/home',pathMatch:'full'},
    {path:'home',component:HomeComponent},
    {path:'Admin',component:AdminComponent},
    {path:'AboutUs',component:AboutUsComponent},
    {path:'addques',component:ADDQuesComponent,canActivate:[AuthGuard]},
    {path:'adminOption',component:AdminOptionComponent,canActivate:[AuthGuard]}





];




