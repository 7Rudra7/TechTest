import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuizService } from '../shared/quiz.service';
import { stringify } from 'querystring';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  constructor(private router: Router,private quizService: QuizService) { }

  ngOnInit() {
   this.xyz();
  }

  sk:string;

  xyz()
  {

    
    this.sk=sessionStorage.getItem("SUBJECT")

    alert(this.sk)
    this.quizService.qnProgress=0;
    this.quizService.getQuestion(this.sk).subscribe(
      (data:any)=>{
        this.quizService.qns=data;
      
      }
    );
  }


  


  Answer(qid,form: NgForm){
   
   

    
    var y = JSON.stringify(form.value);


    var choice=+y[11];
    

    this.quizService.qns[this.quizService.qnProgress].answer = choice;
    localStorage.setItem('qns', JSON.stringify(this.quizService.qns));
    this.quizService.qnProgress++;
  
  
    localStorage.setItem('qnProgress', this.quizService.qnProgress.toString());
    if (this.quizService.qnProgress == 10) {
      
      this.router.navigate(['/result']);
    }


  }










  // Answer(qID,choice){
   





  // //   this.quizService.qns[this.quizService.qnProgress].answer = choice;
  // //   localStorage.setItem('qns', JSON.stringify(this.quizService.qns));
  // //   this.quizService.qnProgress++;
  
  // //   alert(choice)
  // //   localStorage.setItem('qnProgress', this.quizService.qnProgress.toString());
  // //   if (this.quizService.qnProgress == 10) {
      
  // //     this.router.navigate(['/result']);
  // //   }
  //  }
 
  
}
