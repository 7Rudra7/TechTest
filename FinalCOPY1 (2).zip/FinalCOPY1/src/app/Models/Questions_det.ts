export class Questions_det
{
    


    
    Exam_name : string;


}
