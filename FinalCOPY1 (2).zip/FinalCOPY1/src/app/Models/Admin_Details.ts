export class Admin_Details
{


Admin_Email:string;

Admin_password:string;
}