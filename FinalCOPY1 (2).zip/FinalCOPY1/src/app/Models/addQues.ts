export class addQues
{
Q_Id:number;

Question:string;

op1:string;

op2:string;

op3:string;

op4:string;

Answer: number;

level_Id : number;

Subject_name: string;
}

