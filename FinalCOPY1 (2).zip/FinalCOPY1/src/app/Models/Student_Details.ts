export class Student_Details
{
S_Name:string;

S_Email:string;

S_Mobile:string;

S_state:string;

S_city:string;

S_DOB:Date;

S_YOC:number;

S_password:string;

S_Qualification:string;

}