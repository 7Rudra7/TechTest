export class Results
{
    
     Result_status :string;

     E_date :Date;
     E_time :Date;
     Score : number;
      
     S_fId : number;

    
    E_Name : string;


}

