import { Component, OnInit } from '@angular/core';
import { QuizService } from '../shared/quiz.service';
import { Router } from '@angular/router';
import { Results } from '../Models/Results';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {
  
  constructor(private quizService: QuizService, private router: Router) {


   }

  ngOnInit() {
    
    var ee = sessionStorage.getItem("sess_emailID");

    this.quizService.getID(ee).subscribe((data:any)=>
    {
      sessionStorage.setItem("s_fiid",data);
    });
    

    

    this.quizService.getAnswers().subscribe(
        (data: any) => {
           
          this.quizService.correctAnswerCount = 0;  


         this.quizService.qns.forEach((e, i) => {
         
         //alert("QUES:"+this.quizService.qnProgress+" "+e.answer+"=="+data[i])
          if (e.answer == data[i])
          {
           
            this.quizService.correctAnswerCount++;
           
          //e.correct = data[i];
          }
          
        });
  }
    );
    
}

SubmitData() {
  

var s=this.quizService.correctAnswerCount;


var ee = sessionStorage.getItem("sess_emailID");

   
    var x = sessionStorage.getItem("s_fiid");

var y=+x;





var z= sessionStorage.getItem("SUBJECT")

var res_stat="Fail";

if((s/10)*100>=60)
{
res_stat="Pass";
}


let dt = new Date();
 let obj2: Results = {
    Result_status :res_stat,

     E_date :dt,
     E_time :dt,
     Score : s,
     S_fId :y,
    E_Name : z
  
};


    

  this.quizService.UpdateResult(obj2).subscribe(
    (data:any) => {
   
    //this.obj2.S_fId=ee;
      alert("Result updated sucessfully");
      
      this.router.navigate(['/login']);
    
  });

    
  sessionStorage.clear();
 
}




}
