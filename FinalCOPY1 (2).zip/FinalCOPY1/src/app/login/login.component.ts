import { Component, OnInit } from '@angular/core';
import { Student_Details } from '../Models/Student_Details';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { QuizService } from '../shared/quiz.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private quizService: QuizService,private route : Router) { }

  LogForm :FormGroup;
  ngOnInit() {
    this.LogForm = new FormGroup({
   
      S_Email: new FormControl("",Validators.email),
      S_password: new FormControl(),
     
    });
  }

  OnSubmit(obj2:Student_Details)
  {
    this.quizService.getLogdetails(obj2).subscribe(
      (data:any) =>{
        localStorage.clear();
        localStorage.setItem('user',JSON.stringify(data));
        
        
        sessionStorage.setItem("sess_emailID",obj2.S_Email);
        

        if(data==true)
        {
          alert("Logged in sucessfully");
          this.route.navigate(['/exam-ci']);
        }

       else
       {
         alert("Invalid User")
         this.route.navigate(['/login']);
       }
      }
      );
    }
  
  }

