import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuizService } from '../shared/quiz.service';

@Component({
  selector: 'app-admin-option',
  templateUrl: './admin-option.component.html',
  styleUrls: ['./admin-option.component.css']
})
export class AdminOptionComponent implements OnInit {

  constructor(private Router:Router,private quizService:QuizService) { }

  ngOnInit() {
  }

  setSubject(opt:string)
  {
    if(opt=="ADD")
    {
        this.Router.navigate(['/addques']);
    }
  }

  SignOut()
  {
    localStorage.clear();
    sessionStorage.clear();

   this.Router.navigate(['/home']);
  }

}
