import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExamCIComponent } from './exam-ci.component';

describe('ExamCIComponent', () => {
  let component: ExamCIComponent;
  let fixture: ComponentFixture<ExamCIComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExamCIComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExamCIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
