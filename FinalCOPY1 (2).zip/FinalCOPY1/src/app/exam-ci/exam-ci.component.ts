import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-exam-ci',
  templateUrl: './exam-ci.component.html',
  styleUrls: ['./exam-ci.component.css']
})
export class ExamCIComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit() {
  }

  setSubject(sub:string)
  {
    
sessionStorage.setItem("SUBJECT",sub);

    this.router.navigate(['/quiz']);
  }

  SignOut()
  {
    localStorage.clear();
    sessionStorage.clear();
  
  }

}
